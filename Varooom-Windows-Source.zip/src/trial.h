#include <math.h>
typedef struct { double x,z; } Vec2;
typedef struct { double x,y,z; } Vec3;
typedef struct { int count, index[4]; unsigned rgb; } Face;
#include "course.h"
#define COUNT(a) ((int)(sizeof(a)/sizeof((a)[0])))
typedef struct { Vec2 pos; double yaw,speed,timer,last; int next,laps; } Race;
static Race start(void) {
    Race r = {0};
    r.pos = track[0];
    r.next = 1;
    r.yaw = atan2(track[1].x-r.pos.x,r.pos.z-track[1].z);
    return r;
}
static double distance(Vec2 a,Vec2 b) {
    double x=a.x-b.x,z=a.z-b.z;
    return sqrt(x*x+z*z);
}
static void checkpoint(Race *r) {
    if (distance(r->pos,track[r->next]) >= 18) return;
    if (r->next == 0) {
        ++r->laps;
        r->last=r->timer;
        r->timer=0;
    }
    r->next=(r->next+1)%COUNT(track);
}
static void advance(Race *r,double dt,double gas,double steer) {
    Vec2 previous=track[(r->next+COUNT(track)-1)%COUNT(track)];
    int off=distance(r->pos,previous)>20 && distance(r->pos,track[r->next])>20;
    r->speed+=dt*(gas*80-12-r->speed*.12);
    if (r->speed>105) r->speed=105;
    if (off && r->speed>33) r->speed-=90*dt;
    if (r->speed<0) r->speed=0;
    double grip=r->speed<25?r->speed/25:1;
    r->yaw+=dt*steer*2.5*grip;
    r->pos.x+=sin(r->yaw)*r->speed*dt;
    r->pos.z-=cos(r->yaw)*r->speed*dt;
    if (r->speed || r->timer) r->timer+=dt;
    checkpoint(r);
}
