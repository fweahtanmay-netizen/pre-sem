#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include "trial.h"

enum { W=640,H=400 };
static Race race;
static HDC canvas;
static HBITMAP backing,old_bitmap;
static int left_key,right_key,gas,brake;
static POINT project(double x,double y,double z) {
    POINT p={(LONG)(W*.5+(x-race.pos.x)*3),(LONG)(H*.5+(z-race.pos.z)*2.55-y*1.9)};
    return p;
}
static void polygon(POINT *points,int n,unsigned rgb) {
    SetDCBrushColor(canvas,RGB(rgb>>16,(rgb>>8)&255,rgb&255));
    Polygon(canvas,points,n);
}
static POINT edge(int i,double w) {
    Vec2 a=track[(i+COUNT(track)-1)%COUNT(track)],b=track[(i+1)%COUNT(track)];
    double dx=b.x-a.x,dz=b.z-a.z,s=w/sqrt(dx*dx+dz*dz);
    return project(track[i].x+dz*s,0,track[i].z-dx*s);
}
static void strip(int i,int j,double a,double b,unsigned color) {
    POINT quad[]={edge(i,a),edge(j,a),edge(j,b),edge(i,b)};
    polygon(quad,4,color);
}
typedef struct {POINT p[4]; int n; double depth; unsigned rgb;} Surface;
static void draw_car(void) {
    Surface sorted[COUNT(faces)];
    double c=cos(race.yaw),s=sin(race.yaw);
    for(int i=0;i<COUNT(faces);i++) {
        Face f=faces[i];
        Surface face={0};
        face.n=f.count;
        face.rgb=f.rgb;
        for(int j=0;j<f.count;j++){
            Vec3 v=verts[f.index[j]];
            double x=v.x*c-v.z*s,z=v.x*s+v.z*c;
            face.p[j]=project(race.pos.x+x,v.y+5,race.pos.z+z);
            face.depth+=z*1.9+v.y*2.55;
        }
        face.depth/=f.count;
        int j=i;
        while(j && sorted[j-1].depth>face.depth){sorted[j]=sorted[j-1];j--;}
        sorted[j]=face;
    }
    for(int i=0;i<COUNT(faces);i++) polygon(sorted[i].p,sorted[i].n,sorted[i].rgb);
}
static void render(void) {
    POINT grass[]={{0,0},{W+1,0},{W+1,H+1},{0,H+1}};
    polygon(grass,4,0x568f60);
    for(int i=0;i<COUNT(track);i++) {
        if(fabs(track[i].x-race.pos.x)>145 || fabs(track[i].z-race.pos.z)>115)continue;
        int j=(i+1)%COUNT(track);
        strip(i,j,-17,17,i%4<2?0xcf574a:0xf3e8ca);
        strip(i,j,-15.4,15.4,0x414851);
        if(i%4==0)strip(i,j,-.4,.4,0xffeabf);
        if(i==0)strip(i,j,-15.4,15.4,0xf4f2db);
    }
    draw_car();
    char hud[120];
    int len=sprintf(hud,"LAP %d    %.1f s    LAST %.1f s",race.laps+1,race.timer,race.last);
    SetBkColor(canvas,RGB(29,39,43));
    SetTextColor(canvas,RGB(255,247,213));
    TextOutA(canvas,12,10,hud,len);
}
static LRESULT CALLBACK window_proc(HWND h,UINT msg,WPARAM key,LPARAM arg) {
    static DWORD previous;
    switch(msg){
    case WM_CREATE:{
        HDC dc=GetDC(h);
        canvas=CreateCompatibleDC(dc);
        backing=CreateCompatibleBitmap(dc,W,H);
        ReleaseDC(h,dc);
        if(!canvas || !backing)return -1;
        old_bitmap=SelectObject(canvas,backing);
        SelectObject(canvas,GetStockObject(DC_BRUSH));
        SelectObject(canvas,GetStockObject(NULL_PEN));
        race=start();
        previous=GetTickCount();
        SetTimer(h,1,16,NULL);
        return 0;
    }
    case WM_KILLFOCUS:left_key=right_key=gas=brake=0;return 0;
    case WM_KEYDOWN:case WM_KEYUP:{
        int down=msg==WM_KEYDOWN;
        switch(key){
        case VK_LEFT:left_key=down;break;
        case VK_RIGHT:right_key=down;break;
        case VK_UP:gas=down;break;
        case VK_DOWN:brake=down;break;
        case 'R':if(down)race=start();break;
        }
        return 0;
    }
    case WM_TIMER:{
        DWORD now=GetTickCount(),delta=now-previous;
        previous=now;
        if(GetForegroundWindow()==h)advance(&race,(delta>50?50:delta)*.001,gas-1.6*brake,right_key-left_key);
        InvalidateRect(h,NULL,FALSE);
        return 0;
    }
    case WM_PAINT:{
        PAINTSTRUCT ps;RECT size;
        HDC dc=BeginPaint(h,&ps);
        GetClientRect(h,&size);
        render();
        StretchBlt(dc,0,0,size.right,size.bottom,canvas,0,0,W,H,SRCCOPY);
        EndPaint(h,&ps);
        return 0;
    }
    case WM_DESTROY:
        SelectObject(canvas,old_bitmap);DeleteObject(backing);DeleteDC(canvas);
        PostQuitMessage(0);return 0;
    }
    return DefWindowProcA(h,msg,key,arg);
}
int WINAPI WinMain(HINSTANCE instance,HINSTANCE prev,LPSTR args,int show) {
    (void)prev;(void)args;
    WNDCLASSA cls={0};
    cls.lpfnWndProc=window_proc;cls.hInstance=instance;
    cls.hCursor=LoadCursor(NULL,IDC_ARROW);cls.lpszClassName="VarooomTrial";
    if(!RegisterClassA(&cls))return 1;
    HWND h=CreateWindowExA(0,cls.lpszClassName,"Varooom 3D trial | Arrow keys to drive | R to restart",WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT,CW_USEDEFAULT,960,620,NULL,NULL,instance,NULL);
    if(!h)return 1;
    ShowWindow(h,show);
    MSG msg;
    while(GetMessageA(&msg,NULL,0,0)>0){TranslateMessage(&msg);DispatchMessageA(&msg);}
    return 0;
}
