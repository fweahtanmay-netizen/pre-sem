@echo off
setlocal
pushd "%~dp0"
cl /nologo /O2 /std:c11 /Fe:Varooom-Trial.exe src\win.c user32.lib gdi32.lib /link /SUBSYSTEM:WINDOWS
set "result=%ERRORLEVEL%"
popd
exit /b %result%
