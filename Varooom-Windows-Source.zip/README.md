# Varooom 3D Windows time trial

An unofficial first playable Windows prototype based on the Game Boy Advance racer by GValiente, Kaappis and Tempest. Drive a single car around a circuit reconstructed from the original Stage 1 Easy Forwards rival racing line. The native Win32 renderer draws the original player-car mesh. The road geometry, colors, timing and driving physics are new. The original scenery, opponents, audio and other stages are outside this prototype.

## Build and play

On Windows, open an **x64 Native Tools Command Prompt for Visual Studio 2022** with the **Desktop development with C++** workload installed. Run `build.bat` in this folder, then launch `Varooom-Trial.exe`. All course data is embedded in the executable.

Use **Up** to accelerate, **Down** to brake, **Left/Right** to steer and **R** to restart. Follow the course forward from the start stripe. Passing the checkpoints in order and returning to the stripe completes a lap. The HUD shows the current lap time and the last completed lap.

## Credits and asset terms

[Original game](https://gvaliente.itch.io/varooom-3d) · [Pinned upstream source](https://github.com/GValiente/butano/tree/21fa2e7f465ff1c82b018e5339ba3ca574943d67/games/varooom-3d)

The course and car data in `src/course.h` are adapted from Gustavo Valiente's 2021 checkpoint and model headers, under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). This file retains the same license. Changes include sampling every sixth checkpoint, converting vertices and polygon indices to C arrays, and assigning a new palette. The original files are `include/rival_checkpoints/fr_stage_1_easy_forwards_rival_checkpoints.h` and `include/models/fr_model_3d_items_player_car.h`. Retain attribution, keep asset use noncommercial, and share adapted assets under the same terms.
